module PrettyDisplay where

import DataStructure

showPhoneBook :: PhoneBook -> IO()
showPhoneBook [] = do { putStr "" }
showPhoneBook (person:people) = do
    showPerson person
    showPhoneBook people

showPerson :: Person -> IO()
showPerson person = do
    putStrLn "-------------------------"
    putStrLn ""

    putStrLn $ name person
    
    if ((length $ phones person) > 0) then
        showPhones $ phones person
    else putStr ""
    
    if ((length $ phones person) > 0 && (length $ address person) > 0) then
        putStrLn ""
    else putStr ""
    

    if ((length $ address person) > 0) then
        showAddress $ address person
    else putStr ""
    
    if (dob person /= "") then do
        putStrLn ""
        putStrLn $ "DoB: " ++ dob person
        putStrLn ""
    else putStrLn ""
        
showPhones :: Phones -> IO()
showPhones [] = do { putStr "" }
showPhones (phone:phones) = do
    putStrLn $ "  " ++ (fst phone) ++ ": " ++ (snd phone)
    showPhones phones

showAddress :: Address -> IO()
showAddress [] = do { putStr "" }
showAddress (line:address) = do
    putStrLn $ "  " ++ snd line
    showAddress address