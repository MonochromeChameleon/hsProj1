import DataStructure
import DataParser
import XmlWriter
import Queries
import Control.Monad

getCommand = do 
    xs <- readFile "phoneBook.xml"
    let pb = readPhoneBook xs
    line <- getLine
    when (not $ null line) $ do
        executeCommand pb line
        getCommand

main = do 
    showHelp
    getCommand