module Queries where

import DataStructure
import XmlWriter
import PrettyDisplay

showHelp :: IO()
showHelp = do
    putStrLn "Welcome to the Vig, Nits and Hugh phone book program"
    putStrLn "Available commands:"
    putStrLn "    s: Search entries"
    putStrLn "    p: Print entire phone book"
    putStrLn "    a: Add entry"
    putStrLn "    d: Delete entry"
    putStrLn "    x: Show phone book as xml"
    putStrLn "    h: Show this help"
    putStrLn ""
    putStrLn "Press enter to exit"
    
findPerson :: PhoneBook -> Name -> [Person]
findPerson pb nm = (filter (\x -> take (length nm) (name x) == nm) pb)

doSearch :: PhoneBook -> IO()
doSearch pb = do
    putStrLn "Who do you want to search for?"
    searchTerm <- getLine
    if (inPhoneBook pb searchTerm) then
        showPhoneBook $ findPerson pb searchTerm
    else
        putStrLn "Not found"

doAdd :: PhoneBook -> IO()
doAdd pb = do
    putStrLn "Patience, bitch"

doDelete :: PhoneBook -> IO()
doDelete pb = do
    putStrLn "Which user do you want to delete?"
    searchTerm <- getLine
    
    let matchingPeople = findPerson pb searchTerm
    if (length matchingPeople > 0) then
        verifyDelete pb matchingPeople    
    else
        putStrLn "Nobody matches that name"
        
verifyDelete :: PhoneBook -> [Person] -> IO()
verifyDelete pb people = do
    if (length people == 1) then do
        putStrLn "One matching person found:"
        verifyDeletePerson pb (people!!0)
    else do
        putStrLn $ "We found " ++ (show $ length people) ++ " matching entries:"
        showNames 0 people
        
verifyDeletePerson :: PhoneBook -> Person -> IO()
verifyDeletePerson pb person = do
    putStrLn $ "Are you sure you want to delete " ++ (name person) ++ "? [y/N]"
        
    response <- getLine
    
    if (response == "y") then
        putStrLn "Delete functionality doesn't work yet! Hahaha"
    else
        putStrLn "Not deleted"
        
showNames :: Integer -> PhoneBook -> IO ()
showNames _ [] = putStr ""
showNames ix (person:people) = do
    putStrLn $ (show (ix + 1)) ++ ": " ++ (name person)
    showNames (ix + 1) people

inPhoneBook :: PhoneBook -> Name -> Bool
inPhoneBook pb nm = length (filter (\x -> take (length nm) x == nm) (map name pb)) > 0

executeCommand :: PhoneBook -> String -> IO ()
executeCommand pb cmd = do
    case (cmd!!0) of
        's' -> doSearch pb
        'p' -> showPhoneBook pb
        'a' -> doAdd pb
        'd' -> doDelete pb
        'x' -> putStrLn $ writePhoneBook pb
        'h' -> showHelp
        otherwise -> putStrLn "Unknown command"